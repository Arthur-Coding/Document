//
//  LanguageConfig.h
//  LSLanguageLocationDemo
//
//  Created by ArthurShuai on 16/10/21.
//  Copyright © 2016年 ArthurShuai. All rights reserved.
//

#ifndef LanguageConfig_h
#define LanguageConfig_h

/*
 多语言配置
 */

#define kAppLanguageSave(language) [[NSUserDefaults standardUserDefaults] setObject:language forKey:@"appLanguage"]
#define kAppLanguage [[NSUserDefaults standardUserDefaults] objectForKey:@"appLanguage"]
#define kBundle [NSBundle bundleWithPath:[[NSBundle mainBundle] pathForResource:kAppLanguage ofType:@"lproj"]]

#endif /* LanguageConfig_h */
