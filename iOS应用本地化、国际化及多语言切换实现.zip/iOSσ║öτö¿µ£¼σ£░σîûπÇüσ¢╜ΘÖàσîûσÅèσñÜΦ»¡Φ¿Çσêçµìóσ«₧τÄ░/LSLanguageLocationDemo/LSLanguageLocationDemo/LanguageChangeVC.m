//
//  LanguageVC.m
//  Cate
//
//  Created by ArthurShuai on 16/10/18.
//  Copyright © 2016年 qusu. All rights reserved.
//
/*
 多语言切换文件
 */

#import "LanguageChangeVC.h"
#import "LanguageConfig.h"
#import "AppDelegate.h"


@interface LanguageChangeVC ()

@property (nonatomic,strong)NSArray *titleArr;

@end

@implementation LanguageChangeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedStringFromTableInBundle(@"选择语言",nil,kBundle,nil);
    self.tableView.tableFooterView = [[UIView alloc] init];
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    self.tableView.scrollEnabled = NO;
    self.tableView.rowHeight = 50;
    self.tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, -15);
    _titleArr = @[@"中文简体",@"中文繁體",@"English"];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
}
#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textLabel.text = _titleArr[indexPath.row];
    if (([kAppLanguage isEqualToString:@"zh-Hans"] && indexPath.row == 0)||([kAppLanguage isEqualToString:@"zh-Hant"] && indexPath.row == 1)||([kAppLanguage isEqualToString:@"en"] && indexPath.row == 2)) {
        cell.textLabel.textColor = [UIColor orangeColor];
    }
    return cell;
}
#pragma mark - Table viwe delegate
/*
 切换语言
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    if (indexPath.row == 0) {
        kAppLanguageSave(@"zh-Hans");
        [appDelegate gotoMainViewControllerWithLanguage:@"zh-Hans"];
    }else if (indexPath.row == 1){
        kAppLanguageSave(@"zh-Hant");
        [appDelegate gotoMainViewControllerWithLanguage:@"zh-Hant"];
    }else if (indexPath.row == 2){
        kAppLanguageSave(@"en");
        [appDelegate gotoMainViewControllerWithLanguage:@"en"];
    }
}

@end
