//
//  AppDelegate.m
//  LSLanguageLocationDemo
//
//  Created by ArthurShuai on 16/10/21.
//  Copyright © 2016年 ArthurShuai. All rights reserved.
//

#import "AppDelegate.h"
#import "LanguageConfig.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [self localLanguageAutomaticJudgementAndInitialize];
    return YES;
}
#pragma mark 多语言界面初始设置，自动启动对应语言界面
/*
 1.启动时判断是否已经进行应用内语言切换；
 2.若使用storyboard布局，就需要调用不同语言环境下的storyboard；若不使用storyboard，是纯代码或xib方式，不必调用以下的方法；
 3.具体bundle路径.lproj文件名称，请在项目文件中查看。
 */
- (void)localLanguageAutomaticJudgementAndInitialize{
    NSString *language = nil;
    if (!kAppLanguage) {
        NSString *currenLanguage = [NSLocale preferredLanguages].firstObject;
        if ([currenLanguage hasPrefix:@"zh-Hans"]) {
            kAppLanguageSave(@"zh-Hans");
            language = @"zh-Hans";
        }else if ([currenLanguage hasPrefix:@"zh-Hant"]){
            kAppLanguageSave(@"zh-Hant");
            language = @"zh-Hant";
        }else{
            kAppLanguageSave(@"en");
            language = @"en";
        }
    }else{
        language = kAppLanguage;
    }
    [self gotoMainViewControllerWithLanguage:language];
}
- (void)gotoMainViewControllerWithLanguage:(NSString *)language{
    NSString *path = [[NSBundle mainBundle] pathForResource:language ofType:@"lproj"];
    NSBundle *bundle = [NSBundle bundleWithPath:path];
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:bundle];
    self.window = [[UIWindow alloc] init];
    self.window.rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"mainVC"];
    [self.window makeKeyAndVisible];
}

@end
