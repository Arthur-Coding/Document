//
//  LanguageVC.h
//  Cate
//
//  Created by ArthurShuai on 16/10/18.
//  Copyright © 2016年 qusu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LanguageChangeVC : UITableViewController

@end
