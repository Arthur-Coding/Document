//
//  ViewController.m
//  LSLanguageLocationDemo
//
//  Created by ArthurShuai on 16/10/21.
//  Copyright © 2016年 ArthurShuai. All rights reserved.
//

#import "ViewController.h"
#import "LanguageConfig.h"
#import "LanguageChangeVC.h"
#import <MobileCoreServices/MobileCoreServices.h>

//#define kL NSLocalizedStringFromTableInBundle(@"我的",nil,[NSBundle bundleWithPath:@""],@"2")
@interface ViewController ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
#pragma mark - changeLanguage event
- (IBAction)changeLanguage:(UIButton *)sender {
    LanguageChangeVC *languageChangeVC = [[LanguageChangeVC alloc] init];
    [self.navigationController pushViewController:languageChangeVC animated:YES];
}
#pragma mark - openAlbum and Camera
- (IBAction)openAlbum:(UIButton *)sender {
    [self setupImagePickerController:NO];
}
- (IBAction)openCamera:(UIButton *)sender {
    [self setupImagePickerController:YES];
}
- (void)setupImagePickerController:(BOOL)isPhotograph{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.allowsEditing = YES;
    if (isPhotograph) {
        //检查相机模式是否可用
        if (![UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeCamera]) {
            UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:NSLocalizedStringFromTableInBundle(@"提示", nil, kBundle, nil)  message:NSLocalizedStringFromTableInBundle(@"相机不可用", nil, kBundle, nil) preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *action = [UIAlertAction actionWithTitle:NSLocalizedStringFromTableInBundle(@"确定", nil, kBundle, nil) style:UIAlertActionStyleDefault handler:nil];
            [alertVC addAction:action];
            [self presentViewController:alertVC animated:YES completion:nil];
            return;
        }
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        picker.mediaTypes = @[(NSString *)kUTTypeImage];//媒体类型为静态图像
    }else{
        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    }
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:nil];
}
#pragma mark - imagePicker Delegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    [picker dismissViewControllerAnimated:YES completion:nil];
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
}

@end
