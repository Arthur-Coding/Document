//
//  AppDelegate.h
//  LSLanguageLocationDemo
//
//  Created by ArthurShuai on 16/10/21.
//  Copyright © 2016年 ArthurShuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

//切换语言后跳转切换不同的storyboard下对应页面
- (void)gotoMainViewControllerWithLanguage:(NSString *)language;

@end

